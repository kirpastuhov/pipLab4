create function is_a_human_die()
  returns boolean
language plpgsql
as $$
declare
			  die integer;
		begin
			select ИД into die
			from l2_ЧЕЛОВЕК 
			where ДАТА_СМЕРТИ != NULL;
			return integer;
		end;

$$;

alter function is_a_human_die()
  owner to s242093;

