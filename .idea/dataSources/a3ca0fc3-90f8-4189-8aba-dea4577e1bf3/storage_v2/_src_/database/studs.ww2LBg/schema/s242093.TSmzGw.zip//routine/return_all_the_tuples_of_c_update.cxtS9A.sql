create function return_all_the_tuples_of_c_update()
  returns void
language plpgsql
as $$
DECLARE
VERSION varchar(20);
count_tuples int;
BEGIN
select count(ID) into count_tuples from c_mod;
FOR count_tuples IN select c_mod.version  from c_mod LOOP
select version  into VERSION  from c_mod;
  RETURN ; 
END loop; 
END;
$$;

alter function return_all_the_tuples_of_c_update()
  owner to s242093;

