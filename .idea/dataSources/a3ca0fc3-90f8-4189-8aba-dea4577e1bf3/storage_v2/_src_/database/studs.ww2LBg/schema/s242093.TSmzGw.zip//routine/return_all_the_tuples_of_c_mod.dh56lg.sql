create function return_all_the_tuples_of_c_mod()
  returns integer
language plpgsql
as $$
DECLARE
ID int;
--VERSION varchar(20);
BEGIN
WHILE exists (select ID from c_mod) = 't'LOOP
select ID into ID from c_mod;
  RETURN ID;
END loop; 
END;
$$;

alter function return_all_the_tuples_of_c_mod()
  owner to s242093;

