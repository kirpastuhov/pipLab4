create function is_a_human_die(wat integer)
  returns boolean
language plpgsql
as $$
declare
			die date;
		begin
			select * into die
			from l2_ЧЕЛОВЕК 
			where ДАТА_СМЕРТИ != NULL;
			return date;
		end;

$$;

alter function is_a_human_die(integer)
  owner to s242093;

